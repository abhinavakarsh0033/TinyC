/**
 * ASSIGNMENT 5 (TinyC, Parsing)
 * Test file Parsing
 * Pranav Jha (22CS30061)
 * Abhinav Akarsh (22CS30004)
 */

extern volatile _Bool flag;
static const double pi = 31.415e-1;
signed int light_speed = 3E+8;
unsigned short int mem1;
float mem2;
long double mem3;
_Complex mem4;
_Imaginary mem5;

inline void myFunc(int a, ...)
{
    /*This is myFunc
    It does unpredictable things//*/
    int sum = ~a + a;
    if(!sum)
    {
        sum <<= 1;
        sum >>= 2;
        sum = sum << 3;
        sum = sum >> 4;
        sum = (sum | 5);
        sum &= 6;
        sum |= 7;
        sum ^= 8;
    }
    sum %= (a%2 != 0) ? 17 : 19;
    return;
}

int main()
{
    register int Val = 0;
    char arr[] = {'#', 'J', 'f', '0', '1', '\'', '\"', '\?',
                  '\a', '\b', '\f', '\n', '\r', '\t', '\v', '~', '`'};

    int n = sizeof(arr) / sizeof(char);
    for (auto i = 0; i < n; i++)
    {
        do
        {
            switch (i)
            {
                case 3:
                    Val += 10;
                    break;
                case '\'':
                    if (Val = Val + 5)
                        Val -= 10;
                    else
                        Val = Val * 5;
                    break;
                case 4:
                    goto IIT;
                case '%':
                    Val /= 1;
                    Val--;
                    Val *= (Val >= 1);
                default:
                    break;
            }
            i += (i & 1) + (Val ^ 1);
            i = i - 0;
        } while (i > 0 && i <= 5 || i == 8);
        continue;
    }
    char* restrict s = "Indian Institute of Technology, Kharagpur";
IIT:
	mem4 = mem5;
    return 0;
}